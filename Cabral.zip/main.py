def get_function_input(prompt):  #serve para a pessoa escrever uma função
  expression = input(prompt)
  return lambda x: eval(
      expression
  )  #eval para criar uma função lambda que representa a expressão


def compose(f, g):  #Função que recebe as duas funçoes F e G
  return lambda x: f(g(x))


print("Digite a primeira função f(x):")
f = get_function_input(
    "f(x) = "
)  #As funçoes sao convertidas para funçoes lambda usando esse comando

print("Digite a segunda função g(x):")
g = get_function_input("g(x) = ")

gf = compose(g, f)
fg = compose(f, g)
gg = compose(g, g)
ff = compose(f, f)

x = float(input("Digite o valor de x para calcular as composições: "))

result_gf = gf(x)
result_fg = fg(x)
result_gg = gg(x)
result_ff = ff(x)

print(f"(g ° f)({x}) =", result_gf)
print(f"(f ° g)({x}) =", result_fg)
print(f"(g ° g)({x}) =", result_gg)
print(f"(f ° f)({x}) =", result_ff)

#Feito por Crystofe, Murilo e Andressa
